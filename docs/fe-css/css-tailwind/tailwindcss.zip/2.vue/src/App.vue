<script setup lang="ts">
import HelloWorld from './components/HelloWorld.vue'
</script>

<template>
  <div>
  <div class="bg-red-200 text-white size-[200px] relative  rounded-[16px] p-[8px] hover:bg-violet-600">
    xxxx
    <div class="bg-blue-200 size-[100px] absolute top-[30px] left-[20px] rounded-[16px]">
      xxxx
    </div>

    <div class="miaoma-btn">btn</div>

<div class="miaoma-btn-green">btn</div>

  </div>

  <div class="text-shadow-green">有绿色阴影的文字</div>

  <button class="btn-miaoma">btn</button>
  </div>
</template>

<style scoped>
.logo {
  height: 6em;
  padding: 1.5em;
  will-change: filter;
  transition: filter 300ms;
}
.logo:hover {
  filter: drop-shadow(0 0 2em #646cffaa);
}
.logo.vue:hover {
  filter: drop-shadow(0 0 2em #42b883aa);
}
</style>
