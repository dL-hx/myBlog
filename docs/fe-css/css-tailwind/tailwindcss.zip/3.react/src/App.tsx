
import './App.css'

function App() {

  return (
    <>
  <div className="bg-red-200 text-white size-[200px] relative  rounded-[16px] p-[8px] hover:bg-violet-600">
    xxxx
    <div className="bg-blue-200 size-[100px] absolute top-[30px] left-[20px] rounded-[16px]">
      xxxx
    </div>

    <div className="miaoma-btn">btn</div>

<div className="miaoma-btn-green">btn</div>

  </div>

  <div className="text-shadow-green">有绿色阴影的文字</div>

  <button className="btn-miaoma">btn</button>
    </>
  )
}

export default App
