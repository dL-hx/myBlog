/**
 * Button Component
 */

/**
 * size of the Button
*/

export type ButtonSize = 'sm' | 'md' | 'lg';

export type ButtonType = 'primary'  | 'default' | 'success' | 'danger';
