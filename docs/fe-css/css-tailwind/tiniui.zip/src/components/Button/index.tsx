import React from "react";
import styled, { css } from "styled-components";
import "../../theme/style.css"; // 导入主题样式
import { ButtonSize, ButtonType } from "../../types/button";

// https://github.com/dL-hx/mantine/blob/master/packages/%40mantine/core/src/components/Button/Button.tsx


/**
 * 第一点：
 * 组件属性设置
 * 组件的事件设计
 * 组件的数据协议设计
 *
 * 定义Button组件属性接口
 */

interface ButtonProps extends Omit<React.ButtonHTMLAttributes<HTMLButtonElement>, "type"> {
  /** 按钮变体（样式类型） */
  type?: ButtonType;
  /** 按钮尺寸 */
  size?: ButtonSize;
  /** 加载状态（禁用交互并显示加载文本） */
  loading?: boolean; // 新增loading属性
}

// 创建加载状态小图标组件
const Spinner = styled.span`
  width: 12px;
  height: 12px;
  border: 2px solid currentColor;
  border-radius: 50%;
  border-top-color: transparent;
  animation: spin 1s linear infinite;
  margin-right: 8px;
  display: inline-block;
  vertical-align: middle;

  @keyframes spin {
    to { transform: rotate(360deg); }
  }
`;

// 创建样式化按钮组件 - 使用主题变量
const StyledButton = styled.button<ButtonProps>`
  padding: var(--spacing-sm) var(--spacing-md);
  border-radius: var(--border-radius-base);
  border: var(--border-width-base) solid var(--color-neutral-300);
  background-color: var(--color-white);
  color: var(--color-neutral-800);
  font-size: var(--font-size-base);
  cursor: pointer;
  transition: all 0.2s ease;

  &:hover {
    background-color: var(--color-neutral-100);
    border-color: var(--color-neutral-400);
  }

  &:active {
    background-color: var(--color-neutral-200);
  }

  // ... 可基于variant/size扩展样式逻辑
`;

/**
 * 第二点：
 * 根据不同的属性，求解不同组件的Ui 表现
 */
export const useStyle = (props: ButtonProps) => {
  const { type = "default", size = "md" } = props;
  const colorPrefix = type === "primary" ? "primary" : type;
  
  const sizeConfig = {
    sm: { padding: "var(--spacing-xs) var(--spacing-sm)", fontSize: "12px" },
    md: { padding: "var(--spacing-sm) var(--spacing-md)", fontSize: "var(--font-size-base)" },
    lg: { padding: "var(--spacing-md) var(--spacing-lg)", fontSize: "16px" },
  }[size];

  // 返回纯 CSS 字符串（而非 styled-components 的 css 模板）
  return `
    border-radius: var(--border-radius-base);
    border: var(--border-width-base) solid;
    cursor: pointer;
    transition: all 0.2s ease;
    padding: ${sizeConfig.padding};
    font-size: ${sizeConfig.fontSize};
    background-color: var(--color-${colorPrefix}-500);
    border-color: var(--color-${colorPrefix}-500);
    color: ${type === "default" ? "var(--color-default-800)" : "white"};

    &:hover {
      background-color: var(--color-${colorPrefix}-600);
      border-color: var(--color-${colorPrefix}-600);
    }

    &:active {
      background-color: var(--color-${colorPrefix}-700);
    }
  `.replace(/\s+/g, ' ').trim(); // 压缩空格，避免多余换行
};



/**
 * 第三点：
 * 组件的本体
 */
export const Button = (props: ButtonProps) => {
  const { loading } = props;
  const styles = useStyle(props); 
  
  return (
    <StyledButton 
      style={{ cssText: styles }} 
      disabled={loading} // 加载时禁用按钮
    >
      {loading && <Spinner />} {/* 加载状态显示小图标 */}
      {props.children || 'default'} {/* 保持原有文字不变 */}
    </StyledButton>
  );
};

export default Button;
