import React from 'react';

export const Tag = ()=>{
    return <div>tag</div>
}