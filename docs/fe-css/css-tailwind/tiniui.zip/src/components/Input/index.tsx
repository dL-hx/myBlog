import React from 'react';

export const Input = ()=>{
    return <input />
}