import React from 'react';
export declare const Tag: () => React.JSX.Element;
