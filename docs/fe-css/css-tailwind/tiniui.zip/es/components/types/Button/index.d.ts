import React from 'react';
export declare const Button: () => React.JSX.Element;
