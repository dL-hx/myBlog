---
title: 迷你组件库
demo:
    cols: 2

---

## 迷你组件库

`https://d.umijs.org/guide/write-demo`
`https://d.umijs.org/config/markdown`

- Button

```jsx
import React from 'react';

export default () => <h1>Hello dumi!</h1>;
```

```jsx
import React from 'react';
import {Button} from '../src/components/Button';

export default () => <Button type="primary">Hello dumi!</Button>;
```


```jsx
import React from 'react';
import {Button} from '../src/components/Button';

export default () => <Button type="primary" loading>Hello dumi!</Button>;
```



<code src="../src/components/Button/index.tsx"></code>





- Input 

- Tag